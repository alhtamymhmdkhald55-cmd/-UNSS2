# أُنْس | UNSS

مشروع تطبيق أُنْس مبني بواجهة ويب محلية داخل `www/` ويستخدم Capacitor 6 لتجهيزه كتطبيق Android.

## البناء محلياً

يتطلب Node.js 20 و Java 17 و Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

ينتج ملف الاختبار عادةً في:
`android/app/build/outputs/apk/debug/app-debug.apk`

## البناء عبر GitHub Actions

بعد رفع هذه الملفات إلى الفرع `main`، افتح تبويب **Actions** في GitHub واختر **Build Anis Android APK** ثم **Run workflow**. يمكن تنزيل APK الناتج من قسم Artifacts بعد نجاح البناء.

## ملاحظات

- مجلد `android/` غير مضمّن في الأرشيف الأصلي؛ لذلك ينشئه سير العمل تلقائياً باستخدام Capacitor.
- ملف الواجهة `www/index.html` يعتمد على ملفات CSS وJavaScript الموجودة داخل `www/`، لذا يجب إبقاء بنية المجلد كما هي.
- يعتمد تحميل خطوط Cairo وAmiri وغيرها على اتصال الإنترنت لأن الخطوط مرتبطة بـ Google Fonts.
- لم يتم تغيير وظائف التطبيق أو محتوى القرآن/التفسير/الأحاديث أو بقية البيانات في هذه الحزمة.
